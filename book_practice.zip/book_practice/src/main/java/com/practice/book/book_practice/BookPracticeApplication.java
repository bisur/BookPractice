package com.practice.book.book_practice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BookPracticeApplication {

    public static void main(String[] args) {
        SpringApplication.run(BookPracticeApplication.class, args);
    }

}
